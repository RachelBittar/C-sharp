﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace A3
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new ClientContext())
            {

                var client1 = new Client
                {
                    id =1,
                    igroup = "Eletric",
                    idescription = "Eletric Sander",
                    quantity = 7,
                    unity = 59.98
                };

                db.Client.Add(client1);


                Client client2 = new Client
                {
                    id = 2,
                    igroup = "Eletric",
                    idescription = "Power saw",
                    quantity = 18,
                    unity = 99.99
                };
                db.Client.Add(client2);

                Client client3 = new Client
                {
                    id = 3,
                    igroup = "Pneumatic",
                    idescription = "Nail Gun",
                    quantity = 11,
                    unity = 121.55
                };
                db.Client.Add(client3);

                Client client4 = new Client
                {
                    id = 4,
                    igroup = "Manual",
                    idescription = "Hammer",
                    quantity = 76,
                    unity = 11.99
                };

                db.Client.Add(client4);

                Client client5 = new Client
                {
                    id = 5,
                    igroup = "Eletric",
                    idescription = "Lawn mower",
                    quantity = 3,
                    unity = 79.95
                };
                db.Client.Add(client5);

                Client client6 = new Client
                {
                    id = 6,
                    igroup = "Manual",
                    idescription = "Screwdriver",
                    quantity = 106,
                    unity = 7.99
                };
                db.Client.Add(client6);

                Client client7 = new Client
                {
                    id = 7,
                    igroup = "Electric",
                    idescription = "Jig Saw",
                    quantity = 21,
                    unity = 11.95
                };
                db.Client.Add(client7);
                var client8 = new Client
                {
                    id = 8,
                    igroup = "Manual",
                    idescription = "Wrench",
                    quantity = 34,
                    unity = 7.95
                };
                db.Client.Add(client8);


                var client9 = new Client
                {
                    id = 9,
                    igroup = "Pneumatic",
                    idescription = "Air brush",
                    quantity = 55,
                    unity = 44.5
                };

                db.Client.Add(client9);
                db.SaveChanges();


             // 1 ------------------------------------------------------------------------------------- 
                var query = from client in db.Client
                            orderby client.igroup
                            select client;

                Console.WriteLine("1 - Use LINQ to group data by item group and sort the data by item description");

                foreach (var item in query)
                {
                    Console.WriteLine("["+item.igroup + "] -> " + item.idescription);

                }


             // 2 ------------------------------------------------------------------------------------- 

                Console.WriteLine("\n");
                var query2 = from client in db.Client
                                                   orderby client.quantity
                                                   select client;


                Console.WriteLine("2- Use LINQ to select the item description and quantity, and sort the results by quantity");

                foreach (var item in query2)
                {
                    Console.WriteLine(item.idescription + " -> " + item.quantity);
                }

                Console.WriteLine("\n");


                // 3 ------------------------------------------------------------------------------------- 

                var queryResult3 = from client in db.Client
                                                   orderby (client.quantity*client.unity)
                                                   select client;


                Console.WriteLine("3 - Use LINQ to select the item description and its total value (i.e., quantity * unit price), order the ts by total value");

                foreach (var item in queryResult3)
                {
                    Console.WriteLine(item.idescription + " -> total value: " + item.quantity * item.unity);
                }


                Console.WriteLine("\n");


                //4 ------------------------------------------------------------------------------------- 
                List<Client> ts = new List<Client>();

                var querymax = from item in db.Client
                                   orderby  item.unity descending 
                               select item;

                foreach (var item in querymax)
                {
                    ts.Add(item);  

                }

                ts.First();

                Console.WriteLine("4-Use LINQ to retrieve and display the most expensive item");
                Console.WriteLine("Price " +ts.First().unity + " of the most expensive item "+ ts.First().idescription);

                // 5 ------------------------------------------------------------------------------------- 


                var query5 = from item in db.Client
                               orderby (item.unity)
                               select item;


                Console.WriteLine("Use LINQ to reduce the Unit price of all Items by 10%");
         
                foreach (var item in queryResult3)
                {
                    Console.WriteLine(item.idescription + " Reduced price is " + (item.unity) * 0.9);
                }

                Console.WriteLine("\n");

                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();

            }
        }
    }
    public class Client
    {
        [Key]
        public int id { get; set; }
        public string igroup { get; set; }
        public string idescription { get; set; }
        public int quantity { get; set; }
        public double unity { get; set; }

    }


    public class ClientContext : DbContext
    {
        public DbSet<Client> Client { get; set; }
    }
}

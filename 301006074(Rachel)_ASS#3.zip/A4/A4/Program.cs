﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace A4
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new ClientContext())
            {

                var client1 = new Client
                {
                    clientid = 1,
                    clientName = "BK Associates",
                    ClientServer = "Commercial",
                    clientCity = "Toronto",
                    clientRevenue = 23000,
                    clientType = "active"
                };
                db.ClientDB.Add(client1);

                var client2 = new Client
                {
                    clientid = 6,
                    clientName = "Bick",
                    ClientServer = "Industrial",
                    clientCity = "Dallas",
                    clientRevenue = 67900,
                    clientType = "inactive"
                };
                db.ClientDB.Add(client2);

                var client3 = new Client
                {
                    clientid = 19,
                    clientName = "TPH",
                    ClientServer = "Government",
                    clientCity = "Atlanta",
                    clientRevenue = 986000,
                    clientType = "active"
                };
                db.ClientDB.Add(client3);

                var client4 = new Client
                {
                    clientid = 12,
                    clientName = "Crow",
                    ClientServer = "Industrial",
                    clientCity = "Phoenix",
                    clientRevenue = 12600,
                    clientType = "inactive"
                };
                db.ClientDB.Add(client4);

                var client5 = new Client
                {
                    clientid = 56,
                    clientName = "TX Electrics",
                    ClientServer = "Industrial",
                    clientCity = "Portland",
                    clientRevenue = 56400,
                    clientType = "active"
                };
                db.ClientDB.Add(client5);

                var client6 = new Client
                {
                    clientid = 42,
                    clientName = "GRB",
                    ClientServer = "Government",
                    clientCity = "Omaha",
                    clientRevenue = 43700,
                    clientType = "inactive"
                };
                db.ClientDB.Add(client6);

                var client7 = new Client
                {
                    clientid = 98,
                    clientName = "LB&",
                    ClientServer = "Commercial",
                    clientCity = "Toronto",
                    clientRevenue = 990000,
                    clientType = "active"
                };
                db.ClientDB.Add(client7);

                var client8 = new Client
                {
                    clientid = 44,
                    clientName = "H&P",
                    ClientServer = "Commercial",
                    clientCity = "Denver",
                    clientRevenue = 12200,
                    clientType = "active"
                };

                db.ClientDB.Add(client8);
                db.SaveChanges();
                


                // 1 ------------------------------------------------------------------------------------- 
                var query = from client in db.ClientDB
                            orderby client.clientid ascending
                            select client;

                Console.WriteLine("1 - Use LINQ to sort the data by Client ID");

                foreach (var item in query)
                {
                    Console.WriteLine("Name: " + item.clientName + " -> Type: " + item.clientType);

                }

                Console.WriteLine("\n");

                // 2 ------------------------------------------------------------------------------------- 
                var query2 = from client in db.ClientDB
                            orderby client.clientName
                            select client;

                Console.WriteLine("2 - Use LINQ to sort the data by Name and City");

                foreach (var item in query2)
                {
                    Console.WriteLine("Name: "+item.clientName + " City: "+item.clientCity);
                }

                Console.WriteLine("\n");


                // 3 ------------------------------------------------------------------------------------- 
                var query3 = from client in db.ClientDB
                             where client.ClientServer == "Government"
                             select client;

                Console.WriteLine("3 -Use LINQ to select the Government clients and sort the results by Revenue");

                foreach (var item in query3)
                {
                    Console.WriteLine("["+item.ClientServer+"]" + " $"+item.clientRevenue);
                }

                Console.WriteLine("\n");


                // 4 ------------------------------------------------------------------------------------- 
                var query4 = from client in db.ClientDB
                             where client.clientType == "Active"
                             select client;
                List<Client> ts = new List<Client>(); double sum = 0;

                Console.WriteLine("4 - Use LINQ to select only the Active clients and calculate their total Revenue");

                foreach (var item in query4)
                {
                    ts.Add(item);
                    sum += item.clientRevenue;
                    Console.WriteLine("[" + item.clientName + "]" + " $" + sum);
                }


                Console.WriteLine("\n");

                // 5 ------------------------------------------------------------------------------------- 
                var query5 = from client in db.ClientDB
                             orderby client.clientRevenue descending
                             where client.clientType == "Active"
                             select client;

                Console.WriteLine("5 - Use LINQ to retrieve and display the most important Client");

                List<Client> rp = new List<Client>();
                foreach (var item in query5)
                {
                    rp.Add(item);
                }

                rp.First();

                Console.WriteLine("Name: "+ rp.First().clientName + " $" + rp.First().clientRevenue);


                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
        
            }

        }
    }
    public class Client
    {
        [Key]
        public int clientid { get; set; }
        public string clientName { get; set; }
        public string ClientServer { get; set; }
        public string clientCity { get; set; }
        public double clientRevenue { get; set; }
        public string clientType { get; set; }

    }
    public class ClientContext : DbContext
    {
        public DbSet<Client> ClientDB { get; set; }
    }

}

namespace A4.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class del : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Clients",
                c => new
                    {
                        clientid = c.Int(nullable: false, identity: true),
                        clientName = c.String(),
                        ClientServer = c.String(),
                        clientCity = c.String(),
                        clientRevenue = c.Double(nullable: false),
                        clientType = c.String(),
                    })
                .PrimaryKey(t => t.clientid);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Clients");
        }
    }
}
